const AutomationSmartContract = artifacts.require("AutomationSmartContract");

module.exports = function (deployer) {
  deployer.deploy(AutomationSmartContract);
};