from web3 import Web3
import json
from eth_account import Account

class SmartContractInterface:
    def __init__(self, contract_address, abi_path, provider_url):
        # Connect to Ethereum provider
        self.web3 = Web3(Web3.HTTPProvider(provider_url))
        if not self.web3.is_connected():
            raise ConnectionError("Could not connect to the Ethereum network.")

        # Load the contract's ABI
        with open(abi_path, 'r') as abi_file:
            contract_json = json.load(abi_file)
            contract_abi = contract_json['abi']

        # Reference the smart contract
        self.contract = self.web3.eth.contract(
            address=Web3.to_checksum_address(contract_address),
            abi=contract_abi
        )

    def create_insurance_claim(self, user_address, private_key, description):
        tx = self.contract.functions.createInsuranceClaim(description).buildTransaction({
            'from': user_address,
            'nonce': self.web3.eth.get_transaction_count(user_address),
            'gas': 300000,
            'gasPrice': self.web3.to_wei('20', 'gwei')
        })
        return self._send_transaction(tx, private_key)

    def approve_insurance_claim(self, user_address, private_key, claim_id):
        tx = self.contract.functions.approveInsuranceClaim(claim_id).buildTransaction({
            'from': user_address,
            'nonce': self.web3.eth.get_transaction_count(user_address),
            'gas': 300000,
            'gasPrice': self.web3.to_wei('20', 'gwei')
        })
        return self._send_transaction(tx, private_key)

    def schedule_appointment(self, user_address, private_key, date, time):
        tx = self.contract.functions.scheduleAppointment(date, time).buildTransaction({
            'from': user_address,
            'nonce': self.web3.eth.get_transaction_count(user_address),
            'gas': 300000,
            'gasPrice': self.web3.to_wei('20', 'gwei')
        })
        return self._send_transaction(tx, private_key)

    def confirm_appointment(self, user_address, private_key, appointment_id):
        tx = self.contract.functions.confirmAppointment(appointment_id).buildTransaction({
            'from': user_address,
            'nonce': self.web3.eth.get_transaction_count(user_address),
            'gas': 300000,
            'gasPrice': self.web3.to_wei('20', 'gwei')
        })
        return self._send_transaction(tx, private_key)

    def track_prescription(self, user_address, private_key, medication, dosage):
        tx = self.contract.functions.trackPrescription(medication, dosage).buildTransaction({
            'from': user_address,
            'nonce': self.web3.eth.get_transaction_count(user_address),
            'gas': 300000,
            'gasPrice': self.web3.to_wei('20', 'gwei')
        })
        return self._send_transaction(tx, private_key)

    def _send_transaction(self, tx, private_key):
        # Sign with private key, which should be kept safe and never hardcoded in production!
        signed_tx = self.web3.eth.account.sign_transaction(tx, private_key=private_key)
        tx_hash = self.web3.eth.send_raw_transaction(signed_tx.rawTransaction)
        tx_receipt = self.web3.eth.wait_for_transaction_receipt(tx_hash)
        return tx_receipt

# Example usage
if __name__ == "__main__":
    CONTRACT_ADDRESS = "0x00b31D38eF24BBc4A632eeF977850f64DBfBE253"
    ABI_PATH = "C:\\Users\\fayc3\\OneDrive\\Desktop\\New folder\\build\\contracts\\AutomationSmartContract.json"
    PROVIDER_URL = "http://127.0.0.1:7545"  # Ganache or other provider

    USER_ADDRESS = "0xd0AA2A862ad76ac21F3B073373Fed2B0411B7F19"
    PRIVATE_KEY = input(f"Enter the private key for {USER_ADDRESS}: ").strip()

    smart_contract = SmartContractInterface(CONTRACT_ADDRESS, ABI_PATH, PROVIDER_URL)

    # Example operations
    try:
        print("Creating an insurance claim...")
        receipt = smart_contract.create_insurance_claim(USER_ADDRESS, PRIVATE_KEY, "Lost luggage insurance claim")
        print("Transaction receipt:", receipt)

        print("Scheduling an appointment...")
        receipt = smart_contract.schedule_appointment(USER_ADDRESS, PRIVATE_KEY, "2025-04-30", "10:00 AM")
        print("Transaction receipt:", receipt)

    except Exception as e:
        print("An error occurred:", e)